from google import genai

client = genai.Client(
    api_key="AQ.Ab8RN6IacdZLtimgfon8KqK2NfjXNoU3sMWvbI20uPLiLBwQGw"
)

def get_ai_response(prompt):
    try:
        response = client.models.generate_content(
            model="gemini-3.5-flash",
            contents=prompt
        )

        return response.text

    except Exception as e:
        return f"❌ Error:\n\n{e}"