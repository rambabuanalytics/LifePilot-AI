import sys
from google import genai

print("=" * 60)
print("Python Executable:", sys.executable)
print("google.genai File:", genai.__file__)
print("=" * 60)

client = genai.Client(
    api_key="AQ.Ab8RN6IacdZLtimgfon8KqK2NfjXNoU3sMWvbI20uPLiLBwQGw"
)

response = client.models.generate_content(
    model="gemini-3.5-flash",
    contents="Say Hello"
)

print(response.text)