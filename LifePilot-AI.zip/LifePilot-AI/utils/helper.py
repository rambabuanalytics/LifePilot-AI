import re


def extract_section(text, start_heading, end_heading=None):
    """
    Extract text between two markdown headings.
    """

    if end_heading:

        pattern = rf"{re.escape(start_heading)}(.*?){re.escape(end_heading)}"

    else:

        pattern = rf"{re.escape(start_heading)}(.*)"

    match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)

    if match:
        return match.group(1).strip()

    return "Not Available"


def parse_ai_response(response):
    """
    Parse Gemini AI response into structured sections.
    """

    sections = {}

    headings = [

        "# 🧠 AI Decision Report",

        "## 📋 Decision Summary",

        "## ✅ Option 1",

        "## ✅ Option 2",

        "## 📊 Comparison Table",

        "## 🎯 Decision Score",

        "## 📈 Confidence Level",

        "## ⚠ Risk Analysis",

        "## 🌍 Decision Impact Map",

        "## 🚧 Obstacle Predictor",

        "## 🔍 Hidden Dependency Finder",

        "## 🔄 Reverse Failure Engine",

        "## 🏆 Final Recommendation",

        "## 🚀 Execution Plan",

        "## 📅 Weekly Roadmap",

        "## 💡 AI Coach Advice"

    ]

    for i in range(1, len(headings)):

        current = headings[i]

        if i == len(headings) - 1:
            nxt = None
        else:
            nxt = headings[i + 1]

        key = current.replace("##", "").replace("#", "").strip()

        sections[key] = extract_section(
            response,
            current,
            nxt
        )

    return sections