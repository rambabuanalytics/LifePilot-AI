APP_NAME = "LifePilot AI"

TAGLINE = "Think Less. Decide Better."

DECISION_CATEGORIES = [
    "Career",
    "Education",
    "Finance",
    "Technology",
    "Lifestyle",
    "Business"
]

DECISION_CRITERIA = [
    "Cost",
    "Time",
    "Risk",
    "Future Growth",
    "Difficulty",
    "Opportunity"
]