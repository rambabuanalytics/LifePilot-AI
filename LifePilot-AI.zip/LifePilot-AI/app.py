import streamlit as st

from services.prompt_template import create_prompt
from services.gemini_service import get_ai_response

# -----------------------------
# Page Config
# -----------------------------
st.set_page_config(
    page_title="LifePilot AI",
    page_icon="🧠",
    layout="wide"
)

# -----------------------------
# Header
# -----------------------------
st.title("🧠 LifePilot AI")
st.subheader("AI Decision Intelligence Platform")

st.markdown("---")

st.write("Compare two choices and let AI help you make the best decision.")

# -----------------------------
# Inputs
# -----------------------------
col1, col2 = st.columns(2)

with col1:
    option1 = st.text_input(
        "Option 1",
        placeholder="Example: Data Analyst"
    )

with col2:
    option2 = st.text_input(
        "Option 2",
        placeholder="Example: Software Engineer"
    )

goal = st.text_area(
    "Your Goal",
    placeholder="Example: I want a high salary, good work-life balance, remote opportunities and long-term career growth."
)

# -----------------------------
# Analyze Button
# -----------------------------
if st.button("🚀 Analyze Decision", use_container_width=True):

    if not option1 or not option2 or not goal:
        st.warning("⚠ Please fill all the fields.")
        st.stop()

    with st.spinner("🤖 Gemini AI is analyzing your decision..."):

        prompt = create_prompt(option1, option2, goal)

        result = get_ai_response(prompt)

    st.success("✅ Analysis Completed!")

    st.markdown("---")

    st.markdown("# 🧠 AI Decision Report")

    # Display AI Report
    st.markdown(result)

    st.markdown("---")

    # -----------------------------
    # Buttons
    # -----------------------------
    c1, c2, c3 = st.columns(3)

    with c1:
        st.download_button(
            label="📥 Download Report",
            data=result,
            file_name="LifePilot_Report.md",
            mime="text/markdown",
            use_container_width=True
        )

    with c2:
        if st.button("🔄 Analyze Again", use_container_width=True):
            st.rerun()

    with c3:
        st.button(
            "🚀 Execution Mode",
            use_container_width=True,
            disabled=True
        )

    st.balloons()

    st.success("🎉 Your AI Decision Report is Ready!")